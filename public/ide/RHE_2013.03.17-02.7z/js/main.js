'use strict';

var rhe = new RHE();

// onkeypress is only for character (printable) keys, 
// onkeydown/up is for backspace, etc.
$(document).keyup(function(e) {
    var charCodeActv = rhe.charCodes[e.keyCode];
    if (charCodeActv && ('ku' in charCodeActv)) {
        charCodeActv.ku.fn();
    }
    Rainbow.color($('#ed').text(), 'javascript', 
                  function(cde) {$('#ed').html(cde)});
});

$(document).keypress(function(e) {
    var charCode = (typeof e.which == "number" && e.which !== 0)? e.which 
                                                                : e.keyCode;
    switch(e.keyCode) {
        case 8:
        case 13:
            break;
        default:
            $('#ed').append(String.fromCharCode(charCode));
    }
});